<?php

use App\Http\Controllers\EjemploController;
use App\Http\Controllers\AlumnoController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});


Route::resource('ejemplo', EjemploController::class);
Route::resource('alumno', AlumnoController::class);

