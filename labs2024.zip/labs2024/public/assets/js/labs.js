$(document).ready(function(){
	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		},
		timeout:600000
	});	
});

function loadModal(titulo,route){
	$('#modalGeneral #dlgTitle').html(titulo);
	
	$('#modalGeneral #dlgBody').load(route,function(response,status,xhr){
		if(status === "success") {
			
		}else if (status === "error") {	        
	        notificacion('Error',"Error al cargar el contenido: " + xhr.status + " " + xhr.statusText,'error');
	    }
	});

	$('#modalGeneral').modal('hide')
	var myModal = new bootstrap.Modal(document.getElementById('modalGeneral'), {
		keyboard: false
	});
	myModal.show()
}

function accion(btn,ruta,datos){
	var btnHtml;

	btnHtml = $(btn).html();	
	$(btn).prop('disabled', true);

	$.post(ruta,datos,function(result) {
		notificacion(result.tituloMsg,result.mensaje,result.tipoMsg);
		$(btn).html(btnHtml);
		$(btn).prop('disabled', false);
		
		window.location.reload();
		
	}).fail(function (jqXHR,textStatus){
	
	});
	return false;
}

function accionConfirm(btn,ruta,mensaje,datos){
	 Swal.fire(
		{
			title: "Alerta",
			text: mensaje,
			type: "warning",
			showCancelButton: true,
			confirmButtonClass: "btn-danger",
			confirmButtonText: "Sí",
			cancelButtonText: "No",
			showLoaderOnConfirm: true,
			preConfirm: function() {
				return new Promise(function(resolve) {
					accion(btn,ruta,datos);
				})
			}
		}).then((result) => {
			if (result.value) {
				//accion(btn,ruta,datos);
			} else {

			}
		});
}

function notificacion(titulo,mensaje,tipo){
	Swal.fire({
        title: titulo,
        text: mensaje,
        icon: tipo,
        confirmButtonText: 'Aceptar'
    }).then((result) => {
        
    });
}