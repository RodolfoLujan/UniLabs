<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    
    <script src="../assets/js/color-modes.js"></script>
  
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <!-- End fonts -->

    <link rel="stylesheet" href="../assets/vendors/core/core.css">    
    <link rel="stylesheet" href="../assets/vendors/flatpickr/flatpickr.min.css">
    <link rel="stylesheet" href="../assets/fonts/feather-font/css/iconfont.css">
  
    <link rel="stylesheet" href="../assets/css/demo1/style.css">
    <link rel="stylesheet" href="../assets/vendors/sweetalert2/sweetalert2.min.css">
    
  <link rel="shortcut icon" href="{{ asset('assets/images/favicon.ico') }}" />
</head>
<body>
    @include('layouts.modal')
    <div class="main-wrapper">

        @include('layouts.sidebar')
    
        <div class="page-wrapper">
            @include('layouts.topbar')        
            
            <div class="page-content">
                @yield('main-content')                
            </div>
            @include('layouts.footer')        
        </div>
    </div>

    <script src="../assets/vendors/jquery/jquery.min.js"></script>
    <script src="../assets/vendors/sweetalert2/sweetalert2.min.js"></script>

    <!-- core:js -->
    <script src="../assets/vendors/core/core.js"></script>
    <!-- endinject -->

    <script src="../assets/vendors/flatpickr/flatpickr.min.js"></script>
    <script src="../assets/vendors/apexcharts/apexcharts.min.js"></script>    
    <script src="../assets/vendors/feather-icons/feather.min.js"></script>
    <script src="../assets/js/app.js"></script>
    <script src="../assets/js/labs.js"></script>

    @if (session('success'))
        <script type="text/javascript">
              notificacion('Exito','{{session('success')}}','success');
        </script>
    @endif

</body>
</html>    