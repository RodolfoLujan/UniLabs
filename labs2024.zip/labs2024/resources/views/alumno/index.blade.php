@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Lista de Alumnos</h1>
    <a href="{{ route('alumno.create') }}" class="btn btn-primary">Nuevo Alumno</a>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table mt-3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Clave UASLP</th>
                <th>Nombre</th>
                <th>Activo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            @foreach($alumnos as $alumno)
                <tr>
                    <td>{{ $alumno->id }}</td>
                    <td>{{ $alumno->cve_uaslp }}</td>
                    <td>{{ $alumno->nombreCompleto() }}</td>
                    <td>{{ $alumno->activo }}</td>
                    <td>
                        <a href="{{ route('alumno.show', $alumno->id) }}" class="btn btn-info">Ver</a>
                        <a href="{{ route('alumno.edit', $alumno->id) }}" class="btn btn-warning">Editar</a>
                        <form action="{{ route('alumno.destroy', $alumno->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection