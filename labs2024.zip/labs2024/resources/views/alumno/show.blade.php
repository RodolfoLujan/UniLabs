@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Detalles del Alumno</h1>

    <p><strong>Clave UASLP:</strong> {{ $alumno->cve_uaslp }}</p>
    <p><strong>Nombre:</strong> {{ $alumno->nombreCompleto() }}</p>
    <p><strong>Activo:</strong> {{ $alumno->activo }}</p>

    <a href="{{ route('alumno.index') }}" class="btn btn-secondary">Volver</a>
</div>
@endsection