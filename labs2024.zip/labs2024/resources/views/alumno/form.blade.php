@extends('layouts.app')

@section('content')
<div class="container">
    <h1>{{ isset($alumno) ? 'Editar Alumno' : 'Nuevo Alumno' }}</h1>

    <form action="{{ isset($alumno) ? route('alumno.update', $alumno->id) : route('alumno.store') }}" method="POST">
        @csrf
        @if(isset($alumno))
            @method('PUT')
        @endif

        <div class="form-group">
            <label for="cve_uaslp">Clave UASLP</label>
            <input type="text" name="cve_uaslp" id="cve_uaslp" class="form-control" value="{{ $alumno->cve_uaslp ?? '' }}" required>
        </div>

        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" id="nombre" class="form-control" value="{{ $alumno->nombre ?? '' }}" required>
        </div>

        <div class="form-group">
            <label for="apellidos">Apellidos</label>
            <input type="text" name="apellidos" id="apellidos" class="form-control" value="{{ $alumno->apellidos ?? '' }}" required>
        </div>

        <div class="form-group">
            <label for="activo">Activo</label>
            <select name="activo" id="activo" class="form-control">
                <option value="Si" {{ (isset($alumno) && $alumno->activo == 'Si') ? 'selected' : '' }}>Sí</option>
                <option value="No" {{ (isset($alumno) && $alumno->activo == 'No') ? 'selected' : '' }}>No</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">{{ isset($alumno) ? 'Actualizar' : 'Guardar' }}</button>
    </form>
</div>
@endsection