<table class="table table-bordered table-striped">
	<tbody>
		<tr>
			<th>Nombre</th>
			<td>{{ $object->nombre }}</td>
		</tr>
		<tr>
			<th>Apellidos</th>
			<td>{{ $object->apellidos }}</td>
		</tr>
	</tbody>
</table>