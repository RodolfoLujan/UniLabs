<?php $__env->startSection('main-content'); ?>
<div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
  <div>
    <h4 class="mb-3 mb-md-0">Ejemplo</h4>
  </div>          
</div>
<div class="row">
  <div class="col-12 col-xl-12 grid-margin stretch-card">
    <div class="card overflow-hidden">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-baseline mb-4 mb-md-3">
          <h6 class="card-title mb-0">Ejemplo</h6>                          
        </div>
        <div class="row align-items-start mb-2">
          <div class="col-md-7">
            <p class="text-secondary fs-13px mb-3 mb-md-0">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
          </div>
          <div class="col-md-5 d-flex justify-content-md-end">
            <button class="btn btn-primary" onclick="loadModal('Nuevo Ejemplo','<?php echo e(route('ejemplo.create')); ?>')">
                Nuevo
            </button>
          </div>
        </div>
        <div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th width="50px">#</th>                                
                        <th>Nombre</th>                                
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php echo e($loop->iteration); ?>

                                <button type="button" class="btn btn-inverse-secondary btn-icon  btn-xs" onclick="loadModal('Editar Ejemplo','<?php echo e(route('ejemplo.edit',[$item->id])); ?>')"> <i data-feather="edit"></i></button>
                                <button type="button" class="btn btn-inverse-info btn-icon  btn-xs" onclick="loadModal('Editar Ejemplo','<?php echo e(route('ejemplo.show',[$item->id])); ?>')"> <i data-feather="eye"></i></button>
                                <button type="button" class="btn btn-inverse-danger btn-icon  btn-xs" onclick="accionConfirm(this,'<?php echo e(route('ejemplo.destroy',[$item->id])); ?>','Eliminar registro',{_method:'delete'})"><i data-feather="trash-2"></i></button>
                            </td>                                    
                            <td><?php echo e($item->nombreCompleto()); ?></td>                                
                        </tr>                            
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="2">
                                Sin datos
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
      </div>
    </div>
  </div>
</div> <!-- row -->
   
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rgonzalez/Code/ACC/labs2024/resources/views/ejemplo/index.blade.php ENDPATH**/ ?>