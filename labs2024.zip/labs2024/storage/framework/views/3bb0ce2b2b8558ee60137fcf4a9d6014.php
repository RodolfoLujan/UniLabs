<table class="table table-bordered table-striped">
	<tbody>
		<tr>
			<th>Nombre</th>
			<td><?php echo e($object->nombre); ?></td>
		</tr>
		<tr>
			<th>Apellidos</th>
			<td><?php echo e($object->apellidos); ?></td>
		</tr>
	</tbody>
</table><?php /**PATH /Users/rgonzalez/Code/ACC/labs2024/resources/views/ejemplo/info.blade.php ENDPATH**/ ?>