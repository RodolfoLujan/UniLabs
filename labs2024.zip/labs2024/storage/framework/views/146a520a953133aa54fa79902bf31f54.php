<footer class="footer d-flex flex-row align-items-center justify-content-between px-4 py-3 border-top small">
    <p class="text-secondary mb-1 mb-md-0">Copyright © 2024 <a href="https://infocomp.ingenieria.uaslp.mx" target="_blank">Área de Ciencias de la Computación</a></p>    
</footer><?php /**PATH /home/pcn/labs2024/resources/views/layouts/footer.blade.php ENDPATH**/ ?>