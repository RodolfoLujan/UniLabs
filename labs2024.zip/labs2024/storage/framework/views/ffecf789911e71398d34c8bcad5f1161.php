<div class="modal" tabindex="-1" id='modalGeneral'>
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id='dlgTitle'>Modal</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="btn-close"></button>
      </div>
      <div class="modal-body" id="dlgBody">
        
      </div>      
    </div>
  </div>
</div><?php /**PATH /Users/rgonzalez/Code/ACC/labs2024/resources/views/layouts/modal.blade.php ENDPATH**/ ?>