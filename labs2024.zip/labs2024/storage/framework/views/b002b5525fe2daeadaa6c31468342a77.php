<?php
use App\Models\Ejemplo;

	if(!isset($object)){		
		$ruta = route('ejemplo.store');
		$txtBtnAccion = "AGREGAR";
	}else{		
		$ruta = route('ejemplo.update',[$object->id]);
		$txtBtnAccion = "EDITAR";
	}
?>
<div class="form-element py-30 mb-30">	
	<?php if(!isset($object)): ?>
		<?php echo e(html()->form('POST', '/post')->attributes([
			'action' => $ruta,			
			'id' => 'formGeneral',
			'enctype' => 'multipart/form-data',
			'class' => 'row g-3',
			'autocomplete' => 'off'
			])->open()); ?>

	<?php else: ?>
		<?php echo e(html()->modelForm($object,'PUT', '/post')->attributes([
			'action' => $ruta,
			'id' => 'formGeneral',
			'enctype' => 'multipart/form-data',
			'class' => 'row g-3',
			'autocomplete' => 'off'
			])->open()); ?>


	<?php endif; ?>

		<div class="col-md-12">
			<label for="nombre" class="form-label">Nombre</label>
			<?php echo e(html()->text('nombre')->class('form-control')->placeholder('Nombre del usuario')); ?>

		</div>		
		<div class="col-md-12">
			<label for="apellidos" class="form-label">Primer apellido</label>
			<?php echo e(html()->text('apellidos')->class('form-control')->placeholder('Primer apellido')); ?>

		</div>		
		<div class="col-md-12 mt-5">
			<div class="d-md-flex d-grid align-items-center gap-3 float-end">				
			
				<button id="btnSubmit" type="submit" class="btn btn-primary px-4">
					<?php echo e($txtBtnAccion); ?>

				</button>
			</div>
		</div>
		<br><br>


	<?php echo e(html()->form()->close()); ?>

</div><?php /**PATH /Users/rgonzalez/Code/ACC/labs2024/resources/views/ejemplo/form.blade.php ENDPATH**/ ?>