<nav class="sidebar">
  <div class="sidebar-header">
    <a href="#" class="sidebar-brand">
      <?php echo e(config('app.name', 'Laravel')); ?>

    </a>
    <div class="sidebar-toggler">
      <span></span>
      <span></span>
      <span></span>
    </div>
  </div>
  <div class="sidebar-body">
    <ul class="nav" id="sidebarNav">
      <li class="nav-item nav-category">Main</li>
      <li class="nav-item">
        <a href="dashboard.html" class="nav-link">
          <i class="link-icon" data-feather="box"></i>
          <span class="link-title">Dashboard</span>
        </a>
      </li>
      <li class="nav-item nav-category">LABS</li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#ejemplo" role="button" aria-expanded="false" aria-controls="ejemplo">
          <i class="link-icon" data-feather="mail"></i>
          <span class="link-title">Ejemplo</span>
          <i class="link-arrow" data-feather="chevron-down"></i>
        </a>
        <div class="collapse" data-bs-parent="#sidebarNav" id="ejemplo">
          <ul class="nav sub-menu">
            <li class="nav-item">
              <a href="<?php echo e(route('ejemplo.index')); ?>" class="nav-link">Index</a>
            </li>            
          </ul>
        </div>
      </li>   
    </ul>
  </div>
</nav><?php /**PATH /home/pcn/labs2024/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>