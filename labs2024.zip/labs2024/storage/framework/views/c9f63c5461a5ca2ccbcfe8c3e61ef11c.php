<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    
    <script src="../assets/js/color-modes.js"></script>
  
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <!-- End fonts -->

    <link rel="stylesheet" href="../assets/vendors/core/core.css">    
    <link rel="stylesheet" href="../assets/vendors/flatpickr/flatpickr.min.css">
    <link rel="stylesheet" href="../assets/fonts/feather-font/css/iconfont.css">
  
    <link rel="stylesheet" href="../assets/css/demo1/style.css">
    <link rel="stylesheet" href="../assets/vendors/sweetalert2/sweetalert2.min.css">
    
  <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" />
</head>
<body>
    <?php echo $__env->make('layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-wrapper">

        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <div class="page-wrapper">
            <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
            
            <div class="page-content">
                <?php echo $__env->yieldContent('main-content'); ?>                
            </div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
        </div>
    </div>

    <script src="../assets/vendors/jquery/jquery.min.js"></script>
    <script src="../assets/vendors/sweetalert2/sweetalert2.min.js"></script>

    <!-- core:js -->
    <script src="../assets/vendors/core/core.js"></script>
    <!-- endinject -->

    <script src="../assets/vendors/flatpickr/flatpickr.min.js"></script>
    <script src="../assets/vendors/apexcharts/apexcharts.min.js"></script>    
    <script src="../assets/vendors/feather-icons/feather.min.js"></script>
    <script src="../assets/js/app.js"></script>
    <script src="../assets/js/labs.js"></script>

    <?php if(session('success')): ?>
        <script type="text/javascript">
              notificacion('Exito','<?php echo e(session('success')); ?>','success');
        </script>
    <?php endif; ?>

</body>
</html>    <?php /**PATH /Users/rgonzalez/Code/ACC/labs2024/resources/views/layouts/principal.blade.php ENDPATH**/ ?>