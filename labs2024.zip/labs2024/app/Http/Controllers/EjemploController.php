<?php

namespace App\Http\Controllers;

use App\Models\Ejemplo;
use Illuminate\Http\Request;
use Illuminate\Http\Facades\DB;
use Illuminate\Http\Facades\Log;

class EjemploController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(){
        $items = Ejemplo::all();
        return view('ejemplo.index',[
                        'items' => $items                        
                    ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(){
        return view('ejemplo.form',[ ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request){
        try{
            \DB::beginTransaction();
            $datos = [
                'nombre' => $request->nombre,
                'apellidos' => $request->apellidos,
            ];            
            $newObject = Ejemplo::create($datos);
            session()->flash('success', '¡Recurso creado exitosamente!');
            \DB::commit();
        }catch (\Illuminate\Database\QueryException $e) {
            \DB::rollBack();
            $txt = $e->getMessage();
            \Log::error($txt);    
            session()->flash('error', $txt);        
        }
        return redirect()->route('ejemplo.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id){
        $object = Ejemplo::findOrFail($id);
        return view('ejemplo.info',['object' => $object]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id){
        $object = Ejemplo::findOrFail($id);
        return view('ejemplo.form',['object' => $object]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id){
        $object = Ejemplo::findOrFail($id);
        try {            
            \DB::beginTransaction();
            $datos = [
                'nombre' => $request->nombre,
                'apellidos' => $request->apellidos,
            ]; 
            $object->update($datos);
            session()->flash('success', '¡Recurso creado exitosamente!');
            \DB::commit();            
        } catch (\Illuminate\Database\QueryException $e) {
            \DB::rollBack();
            $txt = $e->getMessage();
            \Log::error($txt);    
            session()->flash('error', $txt);        
        }

        return redirect()->route('ejemplo.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id){
        try{
            \DB::beginTransaction();
            $object = Ejemplo::findOrFail($id);
            $object->delete();            
            session()->flash('success', '¡Recurso eliminado exitosamente!');
            \DB::commit();
        }catch (\Illuminate\Database\QueryException $e) {
            \DB::rollBack();
            $txt = $e->getMessage();
            \Log::error($txt);    
            session()->flash('error', $txt); 
        }
        return redirect()->route('ejemplo.index');
    }
}
