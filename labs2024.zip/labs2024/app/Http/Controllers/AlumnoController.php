<?php

namespace App\Http\Controllers;

use App\Models\Alumno;
use Illuminate\Http\Request;

class AlumnoController extends Controller
{
    public function index()
    {
        $alumnos = Alumno::all();
        return view('alumno.index', compact('alumnos'));
    }

    public function create()
    {
        return view('alumno.form');
    }

    public function store(Request $request)
    {
        try {
            \DB::beginTransaction();
            $datos = $request->only(['cve_uaslp', 'nombre', 'apellidos', 'activo']);
            Alumno::create($datos);
            \DB::commit();
            return redirect()->route('alumno.index')->with('success', '¡Alumno creado exitosamente!');
        } catch (\Exception $e) {
            \DB::rollBack();
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    public function show($id)
    {
        $alumno = Alumno::findOrFail($id);
        return view('alumno.show', compact('alumno'));
    }

    public function edit($id)
    {
        $alumno = Alumno::findOrFail($id);
        return view('alumno.form', compact('alumno'));
    }

    public function update(Request $request, $id)
    {
        try {
            \DB::beginTransaction();
            $alumno = Alumno::findOrFail($id);
            $datos = $request->only(['cve_uaslp', 'nombre', 'apellidos', 'activo']);
            $alumno->update($datos);
            \DB::commit();
            return redirect()->route('alumno.index')->with('success', '¡Alumno actualizado exitosamente!');
        } catch (\Exception $e) {
            \DB::rollBack();
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    public function destroy($id)
    {
        try {
            \DB::beginTransaction();
            $alumno = Alumno::findOrFail($id);
            $alumno->delete();
            \DB::commit();
            return redirect()->route('alumno.index')->with('success', '¡Alumno eliminado exitosamente!');
        } catch (\Exception $e) {
            \DB::rollBack();
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }
}