<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ejemplo extends Model
{
    protected $table = 'ejemplos';

    protected $fillable = [
        'nombre',
        'apellidos'
    ];

    public function nombreCompleto(){
        return $this->apellidos.' '.$this->nombre;
    }
}
