<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Registro extends Model
{
    protected $table = 'registros';

    protected $fillable = [
        'cve_uaslp',
        'nombre',
        'apellidos',
        'activo'
    ];

    public function nombreCompleto()
    {
        return $this->nombre . ' ' . $this->apellidos;
    }
}